using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
    public GameObject character; // player character.
    public Collider groundChecker; // irrelevant. too lazy to remove.
    public Rigidbody body; // player rigidbody.

    public float speed = 50.0f; // player speed value.
    public float jumpHeight = 5.0f; // player jump height.

    public float bounceCounter = 1.00f; // this number increases height on continuous jumps.
    public float yVelocity = 0; // tracks y velocity of the player.
    public float xVelocity = 0; // tracks x velocity of the player.
    float maxSpeed = 20.0f; // irrelevant. too lazy to remove.

    bool isGrounded = true; // checks if the player is on a floor surface.

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // update x and y velocity before checking for player input and decelerating x velocity.
        xVelocity = body.velocity.x;
        yVelocity = body.velocity.y;
        CheckInput();
        if (body.velocity.x > 0)
        {
            body.velocity -= new Vector3(Time.deltaTime * 16, 0, 0);
        }
        if (body.velocity.x < 0)
        {
            body.velocity += new Vector3(Time.deltaTime * 16, 0, 0);
        }
    }

    void CheckInput()
    {
        // code for left and right movement and jumping
        if (Input.GetAxis("Horizontal") != 0)
        {
            Vector3 temp = new Vector3(Input.GetAxis("Horizontal") * speed * Time.deltaTime, 0, 0);
            character.transform.position += temp;
        }
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            body.velocity = new Vector3(0, jumpHeight, 0);
        }
    }

    void OnCollisionEnter(Collision other)
    {
        // if player is on floor, player is grounded. reset bounce counter.
        if (other.gameObject.tag == "Floor")
        {
            isGrounded = true;
            Debug.Log("yes.");
            bounceCounter = 1;
        }
        // if player touches a bouncy surface, make them bounce!
        if (other.gameObject.tag == "Bouncy")
        {
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 6)
                {
                    bounceCounter++;
                }
                body.velocity = new Vector3(xVelocity, jumpHeight * (bounceCounter / 2.5f), 0);
                Debug.Log("boing boing, muthafucka!!!");
            }
            else
            {
                body.velocity = new Vector3(xVelocity, jumpHeight, 0);
                Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
        // ditto last comment.
        if (other.gameObject.tag == "DownBounce")
        {
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 6)
                {
                    bounceCounter++;
                }
                body.velocity = new Vector3(xVelocity, (jumpHeight * (bounceCounter / 2.5f)) * -1, 0);
                Debug.Log("boing boing, muthafucka!!!");
            }
            else
            {
                body.velocity = new Vector3(xVelocity, jumpHeight * -1, 0);
                Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
    }

    // player ain't grounded!
    void OnCollisionExit(Collision other)
    {
        isGrounded = false;
        Debug.Log("no fuck off.");
    }

    // ensures that player is considered grounded while standing on a floor. also makes sure bounce counter resets.
    void OnCollisionStay(Collision other)
    {
        if (other.gameObject.tag == "Floor")
        {
            isGrounded = true;
            bounceCounter = 1;
        }
    }
}
