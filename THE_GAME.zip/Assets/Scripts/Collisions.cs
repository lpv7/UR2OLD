using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collisions : MonoBehaviour
{
    public Collider wallCheckerLeft; // left wall collider
    public Collider wallCheckerRight; // right wall collider
    public GameObject character; // player game object
    public Rigidbody body; // player rigidbody

    float bounceCounter = 1.00f; // bounce counter
    float jumpHeight; // player jump height
    float yVelocity; // player y velocity
    float xVelocity; // player x velocity
    Vector3 horiBounce; // irrelevant. too lazy to remove.

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // get values from main player script
        bounceCounter = character.GetComponent<Controller>().bounceCounter;
        jumpHeight = character.GetComponent<Controller>().jumpHeight;
        yVelocity = character.GetComponent<Controller>().yVelocity;
        xVelocity = character.GetComponent<Controller>().xVelocity;
        horiBounce = new Vector3(xVelocity * -1, yVelocity * -1);
    }

    void OnTriggerEnter(Collider other)
    {
        // when wall trigger touches a horizontal bouncy surface, make the player bounce!
        if (other.gameObject.tag == "LeftBounce")
        {
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 6)
                {
                    bounceCounter++;
                }
                body.velocity = new Vector3(jumpHeight * (bounceCounter / 3), yVelocity * 2 + jumpHeight * 1.5f, 0);
                Debug.Log("boing boing, muthafucka!!!");
            }
            else
            {
                body.velocity = new Vector3(jumpHeight * 1.5f, yVelocity * 2 + jumpHeight * 1.5f, 0);
                Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
        // ditto the last comment.
        if (other.gameObject.tag == "RightBounce")
        {
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 6)
                {
                    bounceCounter++;
                }
                body.velocity = new Vector3((jumpHeight * (bounceCounter / 3)) * -1, yVelocity * 2 + jumpHeight * 1.5f, 0);
                Debug.Log("boing boing, muthafucka!!!");
            }
            else
            {
                body.velocity = new Vector3((jumpHeight * 1.5f) * -1, yVelocity * 2 + jumpHeight * 1.5f, 0);
                Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
    }
    void OnTriggerExit(Collider other)
    {
        // this is here in case anything needs to be done in the future.
    }
}
