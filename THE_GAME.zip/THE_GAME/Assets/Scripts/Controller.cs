using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
    public GameObject character; // player character.
    public Rigidbody2D body; // player rigidbody.
    public Collider2D wallCheckerLeft; // left wall collider
    public Collider2D wallCheckerRight; // right wall collider
    public GameObject cameraTriggers; // holds camera triggers

    public float speed = 50.0f; // player speed value.
    public float jumpHeight = 5.0f; // player jump height.

    public float bounceCounter = 1.00f; // this number increases height on continuous jumps.
    public float yVelocity = 0; // tracks y velocity of the player.
    public float xVelocity = 0; // tracks x velocity of the player.
    float maxSpeed = 10.0f; // irrelevant. too lazy to remove.

    bool isGrounded = true; // checks if the player is on a floor surface.
    public bool isBouncing = false; // checks if the player is being bounced.

    public int bounceTimer = 500;
    public int currBounceTimer = 500;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // update x and y velocity before checking for player input and decelerating x velocity.
        xVelocity = body.velocity.x;
        yVelocity = body.velocity.y;
        if (body.velocity.x != 0 && Input.GetAxis("Horizontal") == 0)
        {
            body.velocity = new Vector2(xVelocity * 0.99f, yVelocity);
        }
        if (currBounceTimer < bounceTimer)
        {
            currBounceTimer++;
        }
    }

    void LateUpdate()
    {
        if (currBounceTimer >= bounceTimer)
        {
            CheckInput();
        }
        if (body.velocity.x > 30)
        {
            body.velocity = new Vector2(15, yVelocity);
        }
        if (body.velocity.x < -30)
        {
            body.velocity = new Vector2(-15, yVelocity);
        }
    }

    void CheckInput()
    {
        // code for left and right movement and jumping
        if (Input.GetAxis("Horizontal") != 0)
        {
            Vector2 temp = new Vector2(Input.GetAxis("Horizontal") * speed, yVelocity);
            body.velocity = temp;

            if (body.velocity.x > 5)
            {
                body.velocity -= new Vector2(speed * Time.deltaTime, 0);
            }
            if (body.velocity.x < -5)
            {
                body.velocity += new Vector2(speed * Time.deltaTime, 0);
            }
            // Debug.Log("xVelocity: " + xVelocity);
        }
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            body.velocity = new Vector2(0, jumpHeight);
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        // if player is on floor, player is grounded. reset bounce counter.
        if (other.gameObject.tag == "Floor")
        {
            isGrounded = true;
            // Debug.Log("yes.");
            bounceCounter = 1;
        }
        // if player touches wall or ceiling, let them move.
        
        if (other.gameObject.tag == "Platforms")
        {
            currBounceTimer = bounceTimer;
        }
        // if player touches a bouncy surface, make them bounce!
        if (other.gameObject.tag == "Bouncy")
        {
            
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 6)
                {
                    bounceCounter++;
                }
                body.velocity = new Vector2(xVelocity, jumpHeight * (bounceCounter / 2.5f));
                // Debug.Log("boing boing, muthafucka!!!");
            }
            else
            {
                body.velocity = new Vector2(xVelocity, jumpHeight);
                // Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
        // ditto last comment.
        if (other.gameObject.tag == "DownBounce")
        {
            
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 6)
                {
                    bounceCounter++;
                }
                body.velocity = new Vector2(xVelocity, (jumpHeight * (bounceCounter / 2.5f)) * -1);
                // Debug.Log("boing boing, muthafucka!!!");
            }
            else
            {
                body.velocity = new Vector2(xVelocity, jumpHeight * -1);
                // Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
    }

    // player ain't grounded!
    void OnCollisionExit2D(Collision2D other)
    {
        isGrounded = false;
        // Debug.Log("no fuck off.");
    }

    // ensures that player is considered grounded while standing on a floor. also makes sure bounce counter resets.
    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.tag == "Floor")
        {
            isGrounded = true;
            bounceCounter = 1;
            isBouncing = false;
            currBounceTimer = bounceTimer;
        }
        if (other.gameObject.tag == "Platforms")
        {
            currBounceTimer = bounceTimer;
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // when wall trigger touches a horizontal bouncy surface, make the player bounce!
        if (other.gameObject.tag == "LeftBounce")
        {
            currBounceTimer = 0;
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 6)
                {
                    bounceCounter++;
                }
                if (xVelocity == 0)
                {
                    body.velocity = new Vector2((jumpHeight * 1.5f) * (bounceCounter / 3) * -1, yVelocity / 1.5f);
                }
                else
                {
                    body.velocity = new Vector2((jumpHeight * 1.5f) * (bounceCounter / 3) * -1, yVelocity / 1.5f);
                }
                // Debug.Log("boing boing, muthafucka!!!");
            }
            else
            {
                if (xVelocity == 0)
                {
                    body.velocity = new Vector2(jumpHeight * -1, yVelocity / 2);
                }
                else
                {
                    body.velocity = new Vector2(jumpHeight * -1, yVelocity / 2);
                }
                // Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
        // ditto the last comment.
        if (other.gameObject.tag == "RightBounce")
        {
            currBounceTimer = 0;
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 6)
                {
                    bounceCounter++;
                }
                if (xVelocity == 0)
                {
                    body.velocity = new Vector2(((jumpHeight * 1.5f) * (bounceCounter / 3)), yVelocity * 2 + jumpHeight);
                }
                else
                {
                    body.velocity = new Vector2((jumpHeight * 1.5f) * (bounceCounter / 3), yVelocity * 2 + jumpHeight);
                }
                // Debug.Log("boing boing, muthafucka!!!");

            }
            else
            {
                if (xVelocity == 0)
                {
                    body.velocity = new Vector2(jumpHeight, yVelocity * 1.5f + jumpHeight);
                }
                else
                {
                    body.velocity = new Vector2(jumpHeight, yVelocity * 1.5f + jumpHeight);
                }
                // Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
        if (other.gameObject.tag == "CameraTrigger")
        {
            cameraTriggers.GetComponent<CameraMovement>().MoveCamera(other);
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        // this is here in case anything needs to be done in the future.
    }
}
