using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class DialogueTrigger : MonoBehaviour
{
    [Header("Visual Cue")]
    [SerializeField] public GameObject visualCue;
    [Header("Ink JSON")]
    [SerializeField] public TextAsset inkJSON;
    public Dialogue dialogue;
    private bool playerInRange;
    private Controller controller2d;

    private void Awake()
    {
        playerInRange = false;
        visualCue.SetActive(false);
        controller2d = FindObjectOfType<Controller>();
    }

    private void Update()
    {
        if (playerInRange && !DialogueManager.GetInstance().dialogueIsPlaying)
        {
            visualCue.SetActive(true);
            if (InputManager.GetInstance().GetSubmitPressed())
            {
                controller2d.setCanMove(false);
                DialogueManager.GetInstance().EnterDialogueMode(inkJSON);
            }
        }
        else
        {
            visualCue.SetActive(false);
        }
        if (DialogueManager.GetInstance().dialogueIsPlaying == false)
        {
            controller2d.setCanMove(true);
        }
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "Player")
        {
            playerInRange = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "Player")
        {
            playerInRange = false;
        }
    }
}
