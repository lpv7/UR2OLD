using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collisions : MonoBehaviour
{
    public Collider2D wallCheckerLeft; // left wall collider
    public Collider2D wallCheckerRight; // right wall collider
    public GameObject character; // player game object
    public Rigidbody2D body; // player rigidbody

    float bounceCounter = 1.00f; // bounce counter
    float jumpHeight; // player jump height
    float yVelocity; // player y velocity
    float xVelocity; // player x velocity
    bool isBouncing; // checks if player is bouncing
    Vector3 horiBounce; // irrelevant. too lazy to remove.

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // get values from main player script
        bounceCounter = character.GetComponent<Controller>().bounceCounter;
        jumpHeight = character.GetComponent<Controller>().jumpHeight;
        yVelocity = character.GetComponent<Controller>().yVelocity;
        xVelocity = character.GetComponent<Controller>().xVelocity;
        horiBounce = new Vector2(xVelocity * -1, yVelocity * -1);
        isBouncing = character.GetComponent<Controller>().isBouncing;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // when wall trigger touches a horizontal bouncy surface, make the player bounce!
        if (other.gameObject.tag == "LeftBounce")
        {
            isBouncing = true;
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 5)
                {
                    bounceCounter++;
                }
                if (xVelocity == 0)
                {
                    body.velocity = new Vector2((jumpHeight * 1.5f) * (bounceCounter / 3) * -1, yVelocity / 1.5f);
                }
                else
                {
                    body.velocity = new Vector2((jumpHeight * 1.5f) * (bounceCounter / 3) * -1, yVelocity / 1.5f);
                }
                Debug.Log("boing boing, muthafucka!!!");
            }
            else
            {
                if (xVelocity == 0)
                {
                    body.velocity = new Vector2(jumpHeight * -1, yVelocity / 2);
                }
                else
                {
                    body.velocity = new Vector2(jumpHeight * -1, yVelocity / 2);
                }
                Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
        // ditto the last comment.
        if (other.gameObject.tag == "RightBounce")
        {
            isBouncing = true;
            if (Input.GetButton("Jump"))
            {
                if (bounceCounter < 5)
                {
                    bounceCounter++;
                }
                if (xVelocity == 0)
                {
                    body.velocity = new Vector2(((jumpHeight * 1.5f) * (bounceCounter / 3)), yVelocity / 1.5f); 
                }
                else
                {
                    body.velocity = new Vector2((jumpHeight * 1.5f) * (bounceCounter / 3), yVelocity / 1.5f);
                }
                Debug.Log("boing boing, muthafucka!!!");

            }
            else
            {
                if (xVelocity == 0)
                {
                    body.velocity = new Vector2(jumpHeight, yVelocity / 2);
                }
                else
                {
                    body.velocity = new Vector2(jumpHeight, yVelocity / 2);
                }
                Debug.Log("boing, muthafucka!");
                bounceCounter = 1;
            }
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        // this is here in case anything needs to be done in the future.
    }
}
